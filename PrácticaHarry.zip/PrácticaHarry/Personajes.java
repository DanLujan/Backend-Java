package SEMANA1.PrácticaModelado;

public class Personajes {
    public static void main(String[] args) {
        def();


    }

    public static void def(){

        Hermione Grainger = new Hermione();
        Harry Potter = new Harry();
        Ron Weasley = new Ron();
        Luna Lovegood = new Luna();
        Draco Malfoy = new Draco();

        Grainger.setNombre("Hermione Grainger");
        Grainger.setGenero("Femenino");
        Grainger.setCasa("Gryffindor");
        Grainger.setPatronus("Nutria");
        Grainger.setBoggart("Failure");

        Potter.setNombre("Harry Potter");
        Potter.setGenero("Masculino");
        Potter.setCasa("Gryffindor");
        Potter.setPatronus("Ciervo");

        Weasley.setNombre("Ron Weasley");
        Weasley.setGenero("Masculino");
        Weasley.setCasa("Gryffindor");
        Weasley.setPatronus("Terrier");

        Lovegood.setNombre("Luna Lovegood");
        Lovegood.setGenero("Femenino");
        Lovegood.setCasa("Huflepuff");
        Lovegood.setPatronus("Liebre");

        Malfoy.setNombre("Draco Malfoy");
        Malfoy.setGenero("Maculino");
        Malfoy.setCasa("Slytherin");
        Malfoy.setPatronnus("Dragón");




        String msg = "Los siguientes personajes son de Harry Potter:  ";
        msg += "\n Nombre: "+Grainger.getNombre();
        msg +="\n Genero: "+Grainger.getGenero();
        msg +="\n Casa: "+Grainger.getCasa();
        msg +="\n Patronus: "+Grainger.getPatronus();
        msg +="\n Boggart: "+Grainger.getBoggart();
        msg +="\n Nombre: "+Potter.getNombre();
        msg +="\n Genero: "+Potter.getGenero();
        msg +="\n Casa: "+Potter.getCasa();
        msg +="\n Patronus: "+Potter.getPatronus();
        msg +="\n Nombre: "+Weasley.getNombre();
        msg +="\n Genero: "+Weasley.getGenero();
        msg +="\n Casa: "+Weasley.getCasa();
        msg +="\n Patronus: "+Weasley.getPatronus();
        msg +="\n Nombre: "+Lovegood.getNombre();
        msg +="\n Genero: "+Lovegood.getGenero();
        msg +="\n Casa: "+Lovegood.getCasa();
        msg +="\n Patronus: "+Lovegood.getPatronus();
        msg +="\n Nombre: "+Malfoy.getNombre();
        msg +="\n Genero:"+Malfoy.getGenero();
        msg +="\n Casa:"+Malfoy.getCasa();
        msg +="\n Patronus: "+Malfoy.getPatronus();





        System.out.print(msg);
    }




}
